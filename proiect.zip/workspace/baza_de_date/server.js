var express=require("express")
var Sequelize=require("sequelize")
var nodeadmin=require("nodeadmin")
var cors=require("cors");
var mysql =require('mysql');
var app =express();



//connect to mysql database
var connection = new Sequelize('contactmanager', 'root', '', {
    dialect:'mysql',
    host:'localhost'
})

connection.authenticate().then(function(){
    console.log('Success')
})

var Utilizatori=connection.define('utilizatori',{
    idUtilizator:Sequelize.INTEGER,
    nume:Sequelize.STRING,
    prenume:Sequelize.STRING
})

var Contacte=connection.define('contacte',{
    idContact:Sequelize.STRING,
    nume:Sequelize.STRING,
    telefon:Sequelize.INTEGER
})

Contacte.belongsTo(Utilizatori, {foreignKey: 'idContact', targetKey: 'idUtilizator'})

var app=express();

app.use('/nodeadmin',nodeadmin(app))

app.use(express.static('public'))
app.use('/admin',express.static('admin'))

app.use(express.json());
app.use(express.urlencoded());
app.use(cors());


//adauare utilizator nou
app.post('/utilizator',function(request,response) {
    Utilizatori.create(request.body).then(function(utilizatori){
        response.status(201).send(utilizatori)
    })
})

//adaugare contact nou
app.post('/contacte',function(request,response) {
    Utilizatori.create(request.body).then(function(contacte){
        response.status(201).send(contacte)
    })
})


app.listen(8081)