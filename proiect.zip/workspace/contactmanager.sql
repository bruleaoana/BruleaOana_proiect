SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `contactmanager`
--
CREATE DATABASE `contactmanager` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `contactmanager`;

-- --------------------------------------------------------

--
-- UTILIZATORI
--

CREATE TABLE IF NOT EXISTS `utilizatori` (
  `idUtilizator` smallint(5) NOT NULL AUTO_INCREMENT,
  `nume` varchar(30) DEFAULT NULL,
  `prenume` varchar(100) DEFAULT NULL,
  `createdAt` timestamp,
  `updatedAt` timestamp,
   PRIMARY KEY (`idUtilizator`),
  KEY `idUtilizator` (`idUtilizator`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- CONTACTE
--

CREATE TABLE IF NOT EXISTS `contacte` (
  `idContact` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `idUtilizator` smallint(5) DEFAULT NULL,
  `nume` varchar(30) DEFAULT NULL,
  `telefon` varchar(100) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `createdAt` timestamp,
  `updatedAt` timestamp,
  PRIMARY KEY (`idContact`),
  KEY `idContact` (`idContact`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
