$(document).ready(function(){
    showUtilizatori()
    showContacte()
})

function showUtilizatori() {
    $.get('/utilizatori', function(){
        $.get( "/utilizatori", function( data ) {
            var html = ''
            data.forEach(function(utilizator) {
                html = html + '<li><a href="#" onClick="showProducts('+utilizator.idUtilizator+')">'+utilizator.nume+'</a></li>'
            })
            $('#utilizatori').html(html)
        });
    })
}

//todo: implement showProducts method
function showContacte(idContact) {
    if(idContact) {
        var url = '/urtilizatori/'+ idContact +'/contacte';
    } else {
        var url = '/contacte'   
    }
    $.get(url, function(data) {
        var html = '';
        data.forEach(
            function(contact) {
                html = html + '<div class="contact">'
                  +  '<h2>'+contact.nume+'</h2>'
                  +  '<p>'+contact.prenume+'</p>'
                  +  '<p>telefon: '+contact.telefon+'</p>'
                + '</div>';
            }
        )
        $('#content').html(html);
    })
}
