/*global $*/

$(document).ready(function () {
    readRecords();
});

function readRecords() {
    $.get("/contacte/", {}, function (data, status) {
        data.forEach(function(value) {
            var row = '<tr idContact="row_idContact_'+ value.idContactContact +'">'
            			+ displayColumns(value)
        				+ '</tr>';
            $('#articles').append(row);
        });
    });
}

function displayColumns(value) {
    return 	'<td>'+value.idContactContact+'</td>'
            + '<td class="idContactContact">'+value.utilizatori.idContactUtilizator+'</td>'
            + '<td class="name">'+value.nume+'</td>'
			+ '<td class="telefon">'+value.telefon+'</td>'
			+ '<td align="center">'
			+	'<button onclick="viewRecord('+ value.idContact +')" class="btn btn-edit">Update</button>'
			+ '</td>'
			+ '<td align="center">'
			+	'<button onclick="deleteRecord('+ value.idContact +')" class="btn btn-danger">Delete</button>'
			+ '</td>';
}

function addRecord() {
    $('#idContact').val('');
    $('#idContactContact').val('');
    $('#name').val('');
    $('#telefon').val('');
    
    $('#myModalLabel').html('Adauga un contact nou');
}

function viewRecord(idContact) {
    var url = "/contacte/" + idContact;
    
    $.get(url, {}, function (data, status) {
        //bind the values to the form fields
        $('#idContact').val(data.idContact);
        $('#name').val(data.name);
        $('#telefon').val(data.telefon);
        $('#idContact').val(idContact);
        $('#myModalLabel').html('Edit Product');
        
        $('#add_new_record_modal').modal('show');
    });
}

function saveRecord() {
    //get data from the html form
    var formData = $('#record_form').serializeObject();
    
    //decidContacte if it's an edit or create
    if(formData.idContact) {
        updateRecord(formData);
    } else {
        createRecord(formData);
    }
}

function createRecord(formData) {
    $.ajax({
        url: '/contacte/',
        type: 'POST',
        accepts: {
            json: 'application/json'
        },
        data: formData,
        success: function(data) {
            $('#add_new_record_modal').modal('hide');
            
            var row = '<tr idContact="row_idContact_'+ data.idContact +'">'
            			+ displayColumns(data)
        				+ '</tr>';
            $('#articles').append(row);
        } 
    });
}

function updateRecord(formData) {
    $.ajax({
        url: '/contacte/'+formData.idContact,
        type: 'PUT',
        accepts: {
            json: 'application/json'
        },
        data: formData,
        success: function(data) {
            $('#row_id_'+formData.id+'>td.idContactContact').html(formData.idContactContact);
            $('#row_id_'+formData.id+'>td.name').html(formData.name);
            $('#row_id_'+formData.id+'>td.telefon').html(formData.telefon);
            $('#add_new_record_modal').modal('hide');
        } 
    });
}

function deleteRecord(idContact) {
    $.ajax({
        url: '/contacte/'+idContact,
        type: 'DELETE',
        success: function(data) {
            $('#row_id_'+idContact).remove();
        }
    });
}