/*global $*/

$(document).ready(function () {
    readRecords();
});

// READ records
function readRecords() {
    $.get("/utilizatori/", {}, function (data, status) {
        data.forEach(function(value) {
            var row = '<tr idUtilizator="row_id_'+ value.idUtilizator +'">'
            			+ displayColumns(value)
        				+ '</tr>';
            $('#articles').append(row);
        });
    });
}

function displayColumns(value) {
    return 	'<td>'+value.idUtilizator+'</td>'
            + '<td class="nume">'+value.nume+'</td>'
			+ '<td class="prenume">'+value.prenume+'</td>'
			+ '<td align="center">'
			+	'<button onclick="viewRecord('+ value.idUtilizator +')" class="btn btn-edit">Update</button>'
			+ '</td>'
			+ '<td align="center">'
			+	'<button onclick="deleteRecord('+ value.idUtilizator +')" class="btn btn-danger">Delete</button>'
			+ '</td>';
}

function addRecord() {
    $('#idUtilizator').val('');
    $('#nume').val('');
    $('#prenume').val('');
    
    $('#myModalLabel').html('Adauga utilizator');
  //  $('#add_new_record_modal').modal('show');
}

function viewRecord(idUtilizator) {
    var url = "/utilizatori/" + idUtilizator;
    
    $.get(url, {}, function (data, status) {
        $('#nume').val(data.nume);
        $('#prenume').val(data.prenume);
        $('#idUtilizator').val(idUtilizator);
        $('#myModalLabel').html('Editeaza utilizator');
        $('#add_new_record_modal').modal('show');
    });
}

function saveRecord() {
    var formData = $('#record_form').serializeObject();
    if(formData.idUtilizator) {
        updateRecord(formData);
    } else {
        createRecord(formData);
    }
}

function createRecord(formData) {
    $.ajax({
        url: '/utilizatori/',
        type: 'POST',
        accepts: {
            json: 'application/json'
        },
        data: formData,
        success: function(data) {
            $('#add_new_record_modal').modal('hidUtilizatore');
            
            var row = '<tr idUtilizator="row_id_'+ data.idUtilizator +'">'
            			+ displayColumns(data)
        				+ '</tr>';
            $('#articles').append(row);
        } 
    });
}

function updateRecord(formData) {
    $.ajax({
        url: '/utilizatori/'+formData.idUtilizator,
        type: 'PUT',
        accepts: {
            json: 'application/json'
        },
        data: formData,
        success: function(data) {
            $('#row_id_'+formData.id+'>td.nume').html(formData.nume);
            $('#row_id_'+formData.id+'>td.prenume').html(formData.prenume);
            $('#add_new_record_modal').modal('hide');
        } 
    });
}

function deleteRecord(idUtilizator) {
    $.ajax({
        url: '/utilizatori/'+idUtilizator,
        type: 'DELETE',
        success: function(data) {
            $('#row_idUtilizator_'+idUtilizator).remove();
        }
    });
}